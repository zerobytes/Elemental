var Elemental = (function () {
	function addEvent(evnt, elem, func) {
		if (elem.addEventListener)  // W3C DOM
			elem.addEventListener(evnt, func, false);
		else if (elem.attachEvent) { // IE DOM
			elem.attachEvent("on" + evnt, func);
		}
		else { // No much to do
			elem[evnt] = func;
		}
	}
	return {
		options: {
			default_tag: 'div'
		},
		new: {
			/**
			 * @method custom
			 * @description This method is used to create dom elements recursively
			 * @return DOMelement
			 */
			custom: function (object, parent, forcetag) {				
				//If the passed object is an array then it will
				//iterate those elements configured inside this array 
				//and append inside the parent object
				if (object instanceof Array && parent != undefined) {
					var elemental_items = [], iterator = 0;
					
					for (f in object) {
						//Force some tags to be a specific tag
						//Option case, for select parents
						if (forcetag) object[f].tag = forcetag;
						//creates the new element
						elemental_items[iterator] = Elemental.new.custom(object[f]);
						//Append the created element insde its parent
						parent.appendChild(elemental_items[iterator].get());
						iterator++;
					}
					return elemental_items;
				}
				//Sets DEFAULT tag if tag property not set
				object.tag = (object.tag == undefined ? Elemental.options.default_tag : object.tag).toLowerCase();
				//creates the dom object
				var dom_object = document.createElement(object.tag);
				
				for (i in object) {
					//if (typeof i != 'string') continue;
					switch (i) {
						//All this cases below are about event listeners
						//that will be created to the current element on this
						//recursive method 'Elementa.new.custom'
						//this property must be an object
						case 'event':
						case 'events':
						case 'methods':
						case 'on':
							//Create a listener for each defined event
							for (event in object[i]) {
								addEvent(event, dom_object,object[i][event]);
							}
							break;
							//Al this cases below are about child elements
							//To be appended inside the root element
						case 'items':
						case 'child':
						case 'children':
							var _forcetag = object.tag == 'select' ? 'option' : false;
							object.items = Elemental.new.custom(object[i], dom_object, _forcetag);
							object.children = object.items;
							object.child = object.items;
							break;
						case 'class':
						case 'className':
							dom_object.className = object[i];
							break;
						case 'data':
						case 'data-attributes':
							for (a in object[i]) {
								//Sets the data string attribute to the new object
								dom_object.setAttribute(a, object[i][a]);
							}
							break;
						case 'text':
						case 'string':
						case 'html':
							dom_object.insertAdjacentHTML('beforeend', object[i]);
							break;
						case 'tag':
							break;
						case 'style':
						case 'css':
							for (prop in object[i]) {
								dom_object.style[prop] = object[i][prop];
							}
							break;
						case 'disabled':
						case 'checked':
						case 'readonly':
							if (object[i] == true) dom_object.setAttribute(i, i);
							break;
						default:
							//Sets the string attribute to the new object
							dom_object.setAttribute(i, object[i]);
							break;
					}

				}
				return {
					//Returns dom object
					get: function () {
						return dom_object
					},
					//Adds an item to the object
					addItem: function (items) {
						for (i in items) {
							Elemental.new.custom(items, dom_object);
						}
					},
					//set or unset disabled
					disabled: function (is) {
						this.conditionalAttribute('disabled', 'disabled', is);
					},
					//check or uncheck 
					checkd: function (is) {
						this.conditionalAttribute('checked', 'checked', is);
					},
					//set or unset readonly
					readonly: function (is) {
						this.conditionalAttribute('readonly', 'readonly', is);
					},
					//Add or remove an attribute accordingly to 'IS' param
					conditionalAttribute: function (attribute, value, is) {
						if (is) {
							dom_object.setAttribute(attribute, value);
							return;
						}
						dom_object.removeAttribute(attribute);
					}
				}
			},
			//My example of a custom component implementation by default
			input: function (object, parent) {
				object.tag = 'input';
				return Element.new.custom(object, parent);
			}
		}
	}
}());
